package com.gembooks;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.datafixers.util.Either;
import java.util.List;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.EnchantmentScreen;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.EnchantingTableBlockEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RenderTooltipEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.event.ModifyDefaultComponentsEvent;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

public class ClientEvents {
    private static final ResourceLocation HAMMER =
            ResourceLocation.fromNamespaceAndPath(GemBooks.MODID, "textures/gui/gem_hammer.png");

    /** Draws nothing: removes the floating book above the enchanting table (the ghoul model sits there). */
    public static class HiddenBookRenderer implements BlockEntityRenderer<EnchantingTableBlockEntity> {
        @Override
        public void render(EnchantingTableBlockEntity be, float partialTick, PoseStack poseStack,
                           MultiBufferSource buffer, int packedLight, int packedOverlay) {
        }
    }

    @EventBusSubscriber(modid = GemBooks.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent
        public static void clientSetup(FMLClientSetupEvent event) {
            // item property "gembooks:gem" = (gem index + 1) / 64, read by the resource pack's enchanted_book model
            event.enqueueWork(() -> ItemProperties.register(
                    Items.ENCHANTED_BOOK,
                    ResourceLocation.fromNamespaceAndPath(GemBooks.MODID, "gem"),
                    (stack, level, entity, seed) -> {
                        Gems.Gem gem = Gems.of(stack);
                        return gem == null ? 0.0F : (gem.index() + 1) / 64.0F;
                    }));
        }

        /** The enchanting table item is called "Table Ghoul" everywhere (inventory, hotbar, tooltip). */
        @SubscribeEvent
        public static void modifyDefaults(ModifyDefaultComponentsEvent event) {
            event.modify(Items.ENCHANTING_TABLE, builder -> builder
                    .set(DataComponents.ITEM_NAME, Component.literal("Table Ghoul")));
        }

        @SubscribeEvent
        public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerBlockEntityRenderer(BlockEntityType.ENCHANTING_TABLE, ctx -> new HiddenBookRenderer());
        }
    }

    @EventBusSubscriber(modid = GemBooks.MODID, value = Dist.CLIENT)
    public static class GameBus {
        /** Enchanted books: gem name (+ level) on top, what it does right below, no enchantment lines. */
        @SubscribeEvent
        public static void onTooltip(ItemTooltipEvent event) {
            ItemStack stack = event.getItemStack();
            if (!stack.is(Items.ENCHANTED_BOOK)) return;
            Gems.Found found = Gems.find(stack);
            if (found == null) return;
            List<Component> tip = event.getToolTip();
            if (tip.isEmpty()) return;
            Gems.Gem gem = found.gem();
            MutableComponent title = Component.literal(gem.name())
                    .withStyle(Style.EMPTY.withColor(TextColor.fromRgb(gem.displayColor())));
            if (found.level() > 1 || found.maxLevel() > 1) {
                title.append(" ").append(Component.translatable("enchantment.level." + found.level()));
            }
            tip.set(0, title);
            for (int i = 0; i < found.count() && tip.size() > 1; i++) {
                tip.remove(1); // the vanilla enchantment lines (this also removes the red curse text)
            }
            tip.add(1, Component.literal(gem.desc()).withStyle(ChatFormatting.GRAY));
        }

        /** Enchanting table: hovering an offer also explains what the gem does. */
        @SubscribeEvent
        public static void onGather(RenderTooltipEvent.GatherComponents event) {
            if (!(Minecraft.getInstance().screen instanceof EnchantmentScreen)) return;
            List<Either<FormattedText, TooltipComponent>> elements = event.getTooltipElements();
            if (elements.isEmpty()) return;
            Optional<FormattedText> first = elements.get(0).left();
            if (first.isEmpty() || !(first.get() instanceof Component c)) return;
            if (!(c.getContents() instanceof TranslatableContents tc) || !tc.getKey().equals("container.enchant.clue")) return;
            Object[] args = tc.getArgs();
            if (args.length == 0) return;
            String shown = args[0] instanceof Component ac ? ac.getString() : String.valueOf(args[0]);
            Gems.Gem gem = Gems.byShownName(shown);
            if (gem == null) return;
            elements.add(1, Either.left(Component.literal(gem.desc()).withStyle(ChatFormatting.GRAY)));
        }

        /** Enchanting table screen: hide the "Enchant" title and the black book, show a diamond being hammered. */
        @SubscribeEvent
        public static void onScreen(ScreenEvent.Render.Post event) {
            if (!(event.getScreen() instanceof EnchantmentScreen screen)) return;
            GuiGraphics g = event.getGuiGraphics();
            int x = screen.getGuiLeft(), y = screen.getGuiTop();
            // the 3D book is drawn with its own depth, so lift our drawing in front of it (same trick as tooltips)
            g.pose().pushPose();
            g.pose().translate(0.0F, 0.0F, 400.0F);
            // the 3D book fills the depth buffer, so draw everything pending, clear depth, then paint our picture on top
            g.flush();
            RenderSystem.clear(256, Minecraft.ON_OSX);
            g.fill(x + 7, y + 5, x + 58, y + 15, 0xFFC6C6C6);
            g.blit(HAMMER, x + 14, y + 16, 0, 0, 44, 30, 44, 30);
            g.flush();
            g.pose().popPose();
        }
    }
}
